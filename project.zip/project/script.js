

// Update product information on the page
document.getElementById("product-name").textContent = productData.name;
document.getElementById("product-description").textContent = productData.description;
document.getElementById("product-price").textContent = `Price: $${productData.price.toFixed(2)}`;

// Add to cart button functionality
const addToCartButton = document.getElementById("add-to-cart");
addToCartButton.addEventListener("click", () => {
    // You can add your cart logic here
    alert("Product added to the cart!");
});

function opencandles(){
    window.location.href = "shopcandles.html";
}
function openperfumes(){
    window.location.href = "shopperfumes.html";
}

function required() 
   {
     if (userInput.value.length == 0)
      { 
         alert("Feedback box left empty!");  	
          
      }  	
      else{
        alert("Thank you for your feedback.");
      }
    } 

function thanks(){
    alert("Item added to cart. Thank you for shopping.");
}