const orderEl = document.getElementById('order-el');

const trackEl = document.getElementById('track-el');

const outputEl = document.getElementById('output-el');

trackEl.addEventListener('click', function(){
    if(orderEl.value == 101){
        outputEl.textContent = 'order was delivered successfully on 21-01-2022 at 14:30';
        outputEl.style.color = 'green';
        document.querySelector('.orderstatus').style.visibility = 'visible';
    }

    else if(orderEl.value == 690){
        outputEl.textContent = 'order was confirmed and will be delivered by 02-02-2022'
        outputEl.style.color = 'orange';
        document.querySelector('.orderstatus').style.visibility = 'visible';
    }

    else if(orderEl.value === '' ){
        alert('please enter a valid input')
    }

    else if(orderEl.value < 0){
        alert('please enter a valid input')
    }

    else{
        outputEl.textContent = 'order is under process';
        outputEl.style.color = 'orange';
        document.querySelector('.orderstatus').style.visibility = 'visible';
    }
})